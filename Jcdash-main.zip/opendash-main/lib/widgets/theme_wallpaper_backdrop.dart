import 'dart:io';
import 'dart:ui';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../state/wallpaper_state.dart';
import '../theme/dash_theme.dart';
import '../theme/tokens.dart';

/// Draws the personalized wallpaper configured for [theme] underneath the
/// dashboard gauges, with optional blur and a theme-tinted legibility scrim.
class ThemeWallpaperBackdrop extends ConsumerWidget {
  const ThemeWallpaperBackdrop({super.key, required this.theme});

  final DashTheme theme;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final config = ref.watch(wallpaperProvider.select((m) => m[theme.name]));
    final hasImage = config != null && config.hasImage;

    return IgnorePointer(
      child: AnimatedSwitcher(
        duration: DashMotion.normal,
        switchInCurve: Curves.easeOut,
        switchOutCurve: Curves.easeIn,
        child: !hasImage
            ? const SizedBox.shrink(key: ValueKey('wallpaper-none'))
            : Stack(
                key: ValueKey('wallpaper-${config.path}'),
                fit: StackFit.expand,
                children: [
                  Image.file(
                    File(config.path!),
                    fit: BoxFit.cover,
                    gaplessPlayback: true,
                    filterQuality: FilterQuality.medium,
                    errorBuilder: (_, _, _) => const SizedBox.shrink(),
                  ),
                  if (config.blurSigma > 0.05)
                    ClipRect(
                      child: BackdropFilter(
                        filter: ImageFilter.blur(
                          sigmaX: config.blurSigma,
                          sigmaY: config.blurSigma,
                        ),
                        child: const SizedBox.expand(),
                      ),
                    ),
                  ColoredBox(
                    color: theme.ink.withValues(alpha: config.dimOpacity),
                  ),
                ],
              ),
      ),
    );
  }
}
