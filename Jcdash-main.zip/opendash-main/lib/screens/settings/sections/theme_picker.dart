import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_ui/material_ui.dart';

import '../../../state/theme_state.dart';
import '../../../state/wallpaper_state.dart';
import '../../../theme/colors.dart';
import '../../../theme/dash_theme.dart';
import '../../../theme/tokens.dart';
import '../../../theme/typography.dart';

/// Built-in and custom theme cards with a miniature of the dial, followed by
/// per-theme personalized background wallpaper controls.
class ThemeCards extends ConsumerWidget {
  const ThemeCards({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final current = ref.watch(themeProvider);
    final wallpapers = ref.watch(wallpaperProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 14,
          runSpacing: 16,
          children: [
            for (final t in DashTheme.builtIn)
              _ThemeCardItem(
                theme: t,
                selected: current.name == t.name,
                wallpaper: wallpapers[t.name],
                onTap: () {
                  HapticFeedback.lightImpact();
                  ref.read(themeProvider.notifier).setTheme(t);
                },
              ),
          ],
        ),
        const SizedBox(height: 20),
        ThemeWallpaperSection(theme: current),
      ],
    );
  }
}

class _ThemeCardItem extends StatelessWidget {
  const _ThemeCardItem({
    required this.theme,
    required this.selected,
    required this.wallpaper,
    required this.onTap,
  });

  final DashTheme theme;
  final bool selected;
  final ThemeWallpaper? wallpaper;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final hasWallpaper = wallpaper != null && wallpaper!.hasImage;

    return GestureDetector(
      key: ValueKey('theme-${theme.name.toLowerCase()}'),
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AnimatedContainer(
            duration: DashMotion.fast,
            width: 190,
            height: 114,
            decoration: BoxDecoration(
              color: theme.ink,
              borderRadius: BorderRadius.circular(DashRadius.card),
              border: Border.all(
                color: selected ? DashColors.bone : DashColors.slate,
                width: selected ? 2 : 1.5,
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(DashRadius.card - 1.5),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (hasWallpaper) ...[
                    Image.file(
                      File(wallpaper!.path!),
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => const SizedBox.shrink(),
                    ),
                    ColoredBox(
                      color: theme.ink.withValues(alpha: wallpaper!.dimOpacity),
                    ),
                  ],
                  CustomPaint(painter: _PreviewPainter(theme)),
                  if (hasWallpaper)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: theme.ink.withValues(alpha: 0.72),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: theme.slate, width: 1),
                        ),
                        child: Text(
                          'PHOTO',
                          style: DashText.mode(theme.bone, size: 8),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            theme.name,
            style: DashText.caption(
              16,
              color: selected ? DashColors.bone : DashColors.ash,
            ),
          ),
        ],
      ),
    );
  }
}

class _PreviewPainter extends CustomPainter {
  _PreviewPainter(this.t);
  final DashTheme t;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height * 0.62);
    final rect = Rect.fromCircle(center: c, radius: size.height * 0.42);
    canvas.drawArc(
      rect,
      math.pi * 0.83,
      math.pi * 1.34,
      false,
      Paint()
        ..color = t.slate
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );
    canvas.drawArc(
      rect,
      math.pi * 0.83,
      math.pi * 0.8,
      false,
      Paint()
        ..color = t.bone
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..strokeCap = StrokeCap.round,
    );
    final dots = [t.eco, t.normal, t.sport, t.hyper];
    for (var i = 0; i < dots.length; i++) {
      canvas.drawCircle(
        Offset(size.width * 0.5 + (i - 1.5) * 18, size.height * 0.84),
        4,
        Paint()..color = dots[i],
      );
    }
  }

  @override
  bool shouldRepaint(_PreviewPainter old) => old.t != t;
}

/// Per-theme personalized background wallpaper picker, preview, dimming, and blur.
class ThemeWallpaperSection extends ConsumerStatefulWidget {
  const ThemeWallpaperSection({super.key, required this.theme});

  final DashTheme theme;

  @override
  ConsumerState<ThemeWallpaperSection> createState() => _ThemeWallpaperSectionState();
}

class _ThemeWallpaperSectionState extends ConsumerState<ThemeWallpaperSection> {
  static const _dimPresets = <(String, double)>[
    ('0%', 0.0),
    ('25%', 0.25),
    ('45%', 0.45),
    ('65%', 0.65),
    ('80%', 0.80),
  ];

  static const _blurPresets = <(String, double)>[
    ('Off', 0.0),
    ('Soft', 3.0),
    ('Med', 6.0),
    ('High', 10.0),
  ];

  bool _picking = false;
  String? _error;

  Future<void> _pick() async {
    if (_picking) return;
    HapticFeedback.lightImpact();
    setState(() {
      _picking = true;
      _error = null;
    });
    final err = await ref.read(wallpaperProvider.notifier).pickForTheme(widget.theme.name);
    if (!mounted) return;
    setState(() {
      _picking = false;
      _error = err;
    });
  }

  Future<void> _remove() async {
    HapticFeedback.lightImpact();
    setState(() => _error = null);
    await ref.read(wallpaperProvider.notifier).clearForTheme(widget.theme.name);
  }

  @override
  Widget build(BuildContext context) {
    final theme = widget.theme;
    final config = ref.watch(wallpaperProvider.select((m) => m[theme.name])) ??
        const ThemeWallpaper();
    final hasImage = config.hasImage;

    return Container(
      key: const ValueKey('theme-wallpaper-panel'),
      width: double.infinity,
      padding: const EdgeInsets.all(DashSpace.cardPad),
      decoration: BoxDecoration(
        color: DashColors.inkLift,
        borderRadius: BorderRadius.circular(DashRadius.card),
        border: Border.all(color: DashColors.slate, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${theme.name} wallpaper',
                      style: DashText.caption(16, color: DashColors.bone),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      hasImage
                          ? 'Custom background active for ${theme.name}.'
                          : 'Set a personalized background image for ${theme.name}.',
                      style: DashText.caption(13, color: DashColors.ash),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              _ActionPill(
                key: const ValueKey('wallpaper-pick-btn'),
                label: _picking
                    ? 'Opening...'
                    : (hasImage ? 'Change photo' : 'Add wallpaper'),
                emphasized: true,
                onTap: _picking ? null : _pick,
              ),
              if (hasImage) ...[
                const SizedBox(width: 10),
                _ActionPill(
                  key: const ValueKey('wallpaper-remove-btn'),
                  label: 'Remove',
                  emphasized: false,
                  onTap: _remove,
                ),
              ],
            ],
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(
              _error!,
              style: DashText.caption(13, color: DashColors.warning),
            ),
          ],
          if (hasImage) ...[
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(DashRadius.card - 2),
              child: SizedBox(
                height: 108,
                width: double.infinity,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.file(
                      File(config.path!),
                      fit: BoxFit.cover,
                      gaplessPlayback: true,
                      errorBuilder: (_, _, _) => ColoredBox(color: theme.ink),
                    ),
                    if (config.blurSigma > 0.05)
                      ClipRect(
                        child: BackdropFilter(
                          filter: ImageFilter.blur(
                            sigmaX: config.blurSigma,
                            sigmaY: config.blurSigma,
                          ),
                          child: const SizedBox.expand(),
                        ),
                      ),
                    ColoredBox(
                      color: theme.ink.withValues(alpha: config.dimOpacity),
                    ),
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '64 km/h',
                            style: DashText.caption(24, color: theme.bone),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'DASHBOARD LEGIBILITY PREVIEW',
                            style: DashText.mode(theme.normal, size: 10),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 24,
              runSpacing: 12,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 78,
                      child: Text(
                        'Dimming',
                        style: DashText.caption(14, color: DashColors.ash),
                      ),
                    ),
                    for (final (label, value) in _dimPresets) ...[
                      _ChoiceChip(
                        label: label,
                        selected: (config.dimOpacity - value).abs() < 0.05,
                        onTap: () {
                          HapticFeedback.selectionClick();
                          ref.read(wallpaperProvider.notifier).setDimOpacity(theme.name, value);
                        },
                      ),
                      const SizedBox(width: 8),
                    ],
                  ],
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 78,
                      child: Text(
                        'Blur',
                        style: DashText.caption(14, color: DashColors.ash),
                      ),
                    ),
                    for (final (label, value) in _blurPresets) ...[
                      _ChoiceChip(
                        label: label,
                        selected: (config.blurSigma - value).abs() < 0.5,
                        onTap: () {
                          HapticFeedback.selectionClick();
                          ref.read(wallpaperProvider.notifier).setBlurSigma(theme.name, value);
                        },
                      ),
                      const SizedBox(width: 8),
                    ],
                  ],
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _ActionPill extends StatelessWidget {
  const _ActionPill({
    super.key,
    required this.label,
    required this.emphasized,
    required this.onTap,
  });

  final String label;
  final bool emphasized;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: DashMotion.fast,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: emphasized ? DashColors.bone : DashColors.ink,
          borderRadius: BorderRadius.circular(DashRadius.card),
          border: Border.all(
            color: emphasized ? DashColors.bone : DashColors.slate,
            width: 1.5,
          ),
        ),
        child: Text(
          label,
          style: DashText.caption(
            14,
            color: emphasized ? DashColors.ink : DashColors.bone,
          ),
        ),
      ),
    );
  }
}

class _ChoiceChip extends StatelessWidget {
  const _ChoiceChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: DashMotion.fast,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? DashColors.bone : DashColors.ink,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? DashColors.bone : DashColors.slate,
            width: 1.5,
          ),
        ),
        child: Text(
          label,
          style: DashText.caption(
            13,
            color: selected ? DashColors.ink : DashColors.ash,
          ),
        ),
      ),
    );
  }
}

/// Six mode circles; tapping one reveals the preset grid beneath.
class AccentPicker extends ConsumerStatefulWidget {
  const AccentPicker({super.key});

  @override
  ConsumerState<AccentPicker> createState() => _AccentPickerState();
}

class _AccentPickerState extends ConsumerState<AccentPicker> {
  String? _editing;

  @override
  Widget build(BuildContext context) {
    final theme = ref.watch(themeProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            for (final mode in DashTheme.accentModes) ...[
              GestureDetector(
                key: ValueKey('accent-$mode'),
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _editing = _editing == mode ? null : mode);
                },
                child: Column(
                  children: [
                    AnimatedContainer(
                      duration: DashMotion.fast,
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: theme.accentNamed(mode),
                        border: Border.all(
                          color: _editing == mode ? DashColors.bone : Colors.transparent,
                          width: 2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(mode, style: DashText.mode(DashColors.ash, size: 9)),
                  ],
                ),
              ),
              const SizedBox(width: 22),
            ],
          ],
        ),
        AnimatedSize(
          duration: DashMotion.fast,
          curve: DashMotion.valueCurve,
          alignment: Alignment.topLeft,
          child: _editing == null
              ? const SizedBox.shrink()
              : Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: Container(
                    key: const ValueKey('accent-popover'),
                    padding: const EdgeInsets.all(DashSpace.cardPad),
                    decoration: BoxDecoration(
                      color: DashColors.inkLift,
                      borderRadius: BorderRadius.circular(DashRadius.card),
                      border: Border.all(color: DashColors.slate, width: 1.5),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('$_editing accent', style: DashText.caption(14)),
                        const SizedBox(height: 12),
                        for (var row = 0; row < 2; row++)
                          Padding(
                            padding: EdgeInsets.only(bottom: row == 0 ? 12 : 0),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                for (var i = row * 4; i < row * 4 + 4; i++) ...[
                                  GestureDetector(
                                    key: ValueKey('preset-$i'),
                                    behavior: HitTestBehavior.opaque,
                                    onTap: () {
                                      HapticFeedback.lightImpact();
                                      ref.read(themeProvider.notifier).setAccent(_editing!, accentPresets[i]);
                                    },
                                    child: Container(
                                      width: 44,
                                      height: 44,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: accentPresets[i],
                                        border: Border.all(
                                          color: theme.accentNamed(_editing!) == accentPresets[i]
                                              ? DashColors.bone
                                              : Colors.transparent,
                                          width: 2,
                                        ),
                                      ),
                                    ),
                                  ),
                                  if (i % 4 != 3) const SizedBox(width: 16),
                                ],
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
        ),
      ],
    );
  }
}
