import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../services/prefs_service.dart';
import '../theme/dash_theme.dart';

/// Persisted background wallpaper configuration for a single [DashTheme].
class ThemeWallpaper {
  const ThemeWallpaper({
    this.path,
    this.dimOpacity = defaultDimOpacity,
    this.blurSigma = defaultBlurSigma,
  });

  static const double defaultDimOpacity = 0.45;
  static const double defaultBlurSigma = 0.0;

  final String? path;

  /// Opacity of the theme-tinted scrim drawn over the photo for legibility.
  final double dimOpacity;

  /// Gaussian blur sigma applied to the photo (0 = sharp).
  final double blurSigma;

  bool get hasImage {
    final pth = path;
    if (pth == null || pth.isEmpty) return false;
    try {
      return File(pth).existsSync();
    } catch (_) {
      return false;
    }
  }

  ThemeWallpaper copyWith({
    String? path,
    bool clearPath = false,
    double? dimOpacity,
    double? blurSigma,
  }) =>
      ThemeWallpaper(
        path: clearPath ? null : (path ?? this.path),
        dimOpacity: dimOpacity ?? this.dimOpacity,
        blurSigma: blurSigma ?? this.blurSigma,
      );

  @override
  bool operator ==(Object other) =>
      other is ThemeWallpaper &&
      other.path == path &&
      other.dimOpacity == dimOpacity &&
      other.blurSigma == blurSigma;

  @override
  int get hashCode => Object.hash(path, dimOpacity, blurSigma);
}

class WallpaperNotifier extends Notifier<Map<String, ThemeWallpaper>> {
  final ImagePicker _picker = ImagePicker();

  @override
  Map<String, ThemeWallpaper> build() {
    final loaded = <String, ThemeWallpaper>{};
    for (final theme in DashTheme.builtIn) {
      final rawPath = PrefsService.getString(PrefsKeys.themeWallpaperPath(theme.name), '');
      final dim = PrefsService.getDouble(
        PrefsKeys.themeWallpaperDim(theme.name),
        ThemeWallpaper.defaultDimOpacity,
      ).clamp(0.0, 0.85);
      final blur = PrefsService.getDouble(
        PrefsKeys.themeWallpaperBlur(theme.name),
        ThemeWallpaper.defaultBlurSigma,
      ).clamp(0.0, 12.0);

      String? validPath;
      if (rawPath.isNotEmpty) {
        try {
          if (File(rawPath).existsSync()) {
            validPath = rawPath;
          }
        } catch (_) {
          validPath = null;
        }
      }

      if (validPath != null ||
          dim != ThemeWallpaper.defaultDimOpacity ||
          blur != ThemeWallpaper.defaultBlurSigma) {
        loaded[theme.name] = ThemeWallpaper(
          path: validPath,
          dimOpacity: dim,
          blurSigma: blur,
        );
      }
    }
    return loaded;
  }

  ThemeWallpaper forTheme(String themeName) =>
      state[themeName] ?? const ThemeWallpaper();

  /// Opens the Android image picker and saves an app-private copy for [themeName].
  /// Returns an error message on failure, or `null` on success / user cancel.
  Future<String?> pickForTheme(String themeName) async {
    try {
      final picked = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1920,
        maxHeight: 1080,
        imageQuality: 88,
      );
      if (picked == null) return null;

      final appDir = await getApplicationDocumentsDirectory();
      final wpDir = Directory(p.join(appDir.path, 'theme_wallpapers'));
      if (!wpDir.existsSync()) {
        wpDir.createSync(recursive: true);
      }

      final ext = p.extension(picked.path).isEmpty ? '.jpg' : p.extension(picked.path);
      final slug = themeName.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_');
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final destPath = p.join(wpDir.path, 'wp_${slug}_$stamp$ext');

      await File(picked.path).copy(destPath);

      final previousPath = state[themeName]?.path;
      if (previousPath != null && previousPath != destPath) {
        try {
          final oldFile = File(previousPath);
          if (oldFile.existsSync()) {
            await oldFile.delete();
          }
        } catch (_) {}
      }

      await PrefsService.setString(PrefsKeys.themeWallpaperPath(themeName), destPath);

      final current = forTheme(themeName);
      state = {
        ...state,
        themeName: current.copyWith(path: destPath),
      };
      return null;
    } on PlatformException catch (e) {
      return e.message ?? 'Could not open image picker on this device.';
    } catch (e) {
      return 'Could not save wallpaper: $e';
    }
  }

  Future<void> setDimOpacity(String themeName, double opacity) async {
    final clamped = opacity.clamp(0.0, 0.85);
    await PrefsService.setDouble(PrefsKeys.themeWallpaperDim(themeName), clamped);
    final current = forTheme(themeName);
    state = {
      ...state,
      themeName: current.copyWith(dimOpacity: clamped),
    };
  }

  Future<void> setBlurSigma(String themeName, double sigma) async {
    final clamped = sigma.clamp(0.0, 12.0);
    await PrefsService.setDouble(PrefsKeys.themeWallpaperBlur(themeName), clamped);
    final current = forTheme(themeName);
    state = {
      ...state,
      themeName: current.copyWith(blurSigma: clamped),
    };
  }

  Future<void> clearForTheme(String themeName) async {
    final previousPath = state[themeName]?.path;
    if (previousPath != null) {
      try {
        final oldFile = File(previousPath);
        if (oldFile.existsSync()) {
          await oldFile.delete();
        }
      } catch (_) {}
    }

    await PrefsService.remove(PrefsKeys.themeWallpaperPath(themeName));
    final current = forTheme(themeName);
    state = {
      ...state,
      themeName: current.copyWith(clearPath: true),
    };
  }
}

final wallpaperProvider =
    NotifierProvider<WallpaperNotifier, Map<String, ThemeWallpaper>>(
  WallpaperNotifier.new,
);
